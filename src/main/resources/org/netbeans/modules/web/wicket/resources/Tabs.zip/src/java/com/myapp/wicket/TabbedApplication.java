/*
 * TabbedApplication.java
 *
 * Created on 23 August 2009, 10:55 PM
 */
 
package com.myapp.wicket;           

import org.apache.wicket.protocol.http.WebApplication;
/** 
 *
 * @author geertjan
 * @version 
 */

public class TabbedApplication extends WebApplication {

    public TabbedApplication() {
    }

    public Class getHomePage() {
        return TabbedPanelPage.class;
    }
}
