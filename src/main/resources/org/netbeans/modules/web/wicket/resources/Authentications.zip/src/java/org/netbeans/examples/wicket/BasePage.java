package org.netbeans.examples.wicket;

import org.netbeans.examples.wicket.navigation.WicketExampleHeader;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.model.IModel;
import org.apache.wicket.util.string.Strings;

/**
 *
 * @author Tim Boudreau
 */
public abstract class BasePage<T extends IModel> extends WebPage {
    private final T model;
    public BasePage() {
        this(null);
    }

    public BasePage(T model) {
        super(model);
        this.model = model;
        final String packageName = getClass().getPackage().getName();
        add(new WicketExampleHeader("mainNavigation", Strings.afterLast(packageName, '.')));
    }

    @SuppressWarnings("unchecked")
    protected T model() {
        return (T) model;
    }
}

