/*
 * PizzaModel.java
 *
 * Created on March 19, 2006, 7:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.myapp.wicket;

import java.io.Serializable;

/**
 *
 * @author Geertjan Wielenga
 */
public class PizzaPojo implements Serializable {
    private String crust;
    private boolean pepperoni;
    private boolean sausage;
    private boolean onions;
    private boolean greenPeppers;
    private String comments;
    
    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }
    public String getCrust() {
        return crust;
    }
    public void setCrust(String crust) {
        this.crust = crust;
    }
    public boolean getGreenPeppers() {
        return greenPeppers;
    }
    public void setGreenPeppers(boolean greenPeppers) {
        this.greenPeppers = greenPeppers;
    }
    public boolean getOnions() {
        return onions;
    }
    public void setOnions(boolean onions) {
        this.onions = onions;
    }
    public boolean getPepperoni() {
        return pepperoni;
    }
    public void setPepperoni(boolean pepperoni) {
        this.pepperoni = pepperoni;
    }
    public boolean getSausage() {
        return sausage;
    }
    public void setSausage(boolean sausage) {
        this.sausage = sausage;
    }
}
