/*
 * WicketExampleHeader.java
 *
 * Created on October 14, 2006, 12:29 AM
 */
 
package com.myapp.wicket.support;           

import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.panel.Panel;

/** 
 *
 * @author Geertjan Wielenga
 * @version 
 */

public class WicketExampleHeader extends Panel {

    /**
     * Construct.
     * @param componentName name of the component
     * @param exampleTitle title of the example
     */

    public WicketExampleHeader(String componentName, String exampleTitle)
    {
        super(componentName);
        add(new Label("exampleTitle", exampleTitle));
    }

}
