/*
 * ExampleSession.java
 * 
 * Created on Aug 15, 2007, 1:37:46 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.netbeans.examples.wicket;

import org.apache.wicket.Request;
import org.apache.wicket.protocol.http.WebApplication;
import org.apache.wicket.protocol.http.WebSession;
import org.netbeans.examples.wicket.pojos.User;

/**
 *
 * @author Tim Boudreau
 */
public final class ExampleSession extends WebSession {
    private User user;
    ExampleSession (WebApplication app, Request request) {
        super (app, request);
    }
    
    void setCurrentUser (User user) {
        this.user = user;
    }
    
    public User getCurrentUser() {
        return this.user;
    }

    public boolean isSignedIn() {
        return user != null;
    }
}
