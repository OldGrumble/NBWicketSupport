package org.netbeans.examples.wicket.navigation;

import org.netbeans.examples.wicket.*;
import org.apache.wicket.Session;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.link.BookmarkablePageLink;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.PropertyModel;
import org.netbeans.examples.wicket.home.HomePage;
import org.netbeans.examples.wicket.login.ChangePasswordPage;
import org.netbeans.examples.wicket.login.SignInPage;
import org.netbeans.examples.wicket.login.SignOut;

/**
 *
 * @author Tim Boudreau
 */
public class WicketExampleHeader extends Panel {

    public WicketExampleHeader(String componentName, String exampleTitle) {
        super(componentName);
        add(new Label("example-title", exampleTitle));
        
        //Allow clicking on the logo/title at the top to go back to the
        //home page
        BookmarkablePageLink home = new BookmarkablePageLink("home", 
                HomePage.class);
        add (home);
                
        //And a link to the home page in the navigation items
        BookmarkablePageLink homeLink = new BookmarkablePageLink("home-link", 
                HomePage.class);
        add (homeLink);
        
        //A login link to take users to the login form
        BookmarkablePageLink loginLink = new BookmarkablePageLink("login-link", 
                SignInPage.class);
        add(loginLink);
        
        //Now find out if there is a user logged in
        ExampleSession sess = (ExampleSession) Session.get();
        IModel mdl = null;
        if (sess.isSignedIn()) {
            mdl = new PropertyModel(sess, "currentUser");
        }
        
        //Add a label in the upper left with the user's name
        add(new Label("current-user", mdl));

        //Add a link for changing the password.  It will take the user to
        //the login page if not logged in
        BookmarkablePageLink pwLink = 
                new BookmarkablePageLink("change-password-link",
                ChangePasswordPage.class);
        add (pwLink);

        //Create a logout link, only to be shown if the user is logged in
        BookmarkablePageLink logoutLink = 
                new BookmarkablePageLink("logout-link", SignOut.class);
        add (logoutLink);
        //Only show login or logout depending on whether the user is
        //logged in
        loginLink.setVisible (!sess.isSignedIn());
        logoutLink.setVisible (sess.isSignedIn());
    }
}
