package org.netbeans.examples.wicket;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Annotation to be applied to page classes which should only be accessed
 * via https.
 *
 * @author Tim Boudreau
 */
@Retention(RetentionPolicy.RUNTIME)
 public @interface RequiresSSL { }
