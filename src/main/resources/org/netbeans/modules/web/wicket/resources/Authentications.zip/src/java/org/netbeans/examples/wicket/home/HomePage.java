package org.netbeans.examples.wicket.home;
import org.apache.wicket.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.netbeans.examples.wicket.BasePage;

/**
 * Home page for the example application.
 * 
 * @author Tim Boudreau
 */ 
public class HomePage extends BasePage {
    
    /** Create a home page w/ no parameters */
    public HomePage() {
        this ((String) null);
    }
    
    /** Create a home page that receives a welcome message argument in its
     * URL */
    public HomePage (PageParameters params) {
        this (params.getString("message"));        
    }
    
    /**
     * Create a home page that includes a welcome message after the user 
     * logs in.  See SignInPanel and RegisterPanel for details.
     */ 
    private HomePage (String welcomeMessage) {
        Label welcomeLabel = new Label ("welcome", welcomeMessage == null ? 
            "" : welcomeMessage);
        welcomeLabel.setVisible (welcomeMessage != null);
        add (welcomeLabel);
        
        add (new UsersPanel("users"));
    }
}
