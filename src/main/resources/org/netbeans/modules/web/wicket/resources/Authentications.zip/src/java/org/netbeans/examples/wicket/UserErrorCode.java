/*
 * UserErrorCode.java
 * 
 * Created on Jul 23, 2007, 10:51:18 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.netbeans.examples.wicket;

/**
 * Error codes that can be returned by the login and add user methods on
 * UserDatabase
 *
 * @author Tim Boudreau
 */
    
public enum UserErrorCode {
    PASSWORD_EMPTY_OR_NULL, USER_EXISTS, BAD_PASSWORD, INCORRECT_PASSWORD,
    UNKNOWN_USER, NON_MATCHING_PASSWORD, EXCEPTION, EMPTY_EMAIL, BAD_EMAIL;
    //XXX localize
    @Override
    public String toString() {
        switch (this) {
        case BAD_PASSWORD :
            return "Bad password";
        case USER_EXISTS :
            return "User already exists";
        case PASSWORD_EMPTY_OR_NULL :
            return "Password is empty";
        case INCORRECT_PASSWORD :
            return "Incorrect password";
        case UNKNOWN_USER :
            return "Unknown user";
        case NON_MATCHING_PASSWORD :
            return "Passwords did not match";
        case EXCEPTION :
            return "Exception occured";
        case EMPTY_EMAIL :
            return "Email address not supplied";
        case BAD_EMAIL :
            return "Not a valid email address";
        default :
            throw new AssertionError();
        }
    }
}