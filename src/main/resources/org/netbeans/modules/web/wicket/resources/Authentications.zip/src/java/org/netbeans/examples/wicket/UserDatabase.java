/*
 * UserDatabase.java
 * 
 * Created on Aug 15, 2007, 1:20:43 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.netbeans.examples.wicket;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.netbeans.examples.wicket.pojos.User;

/**
 * A fake database of fake users
 *
 * @author Tim Boudreau
 */
public abstract class UserDatabase {
    private Set <User> users = new HashSet <User>();
    UserDatabase() {
        //Add some dummy users
        addUser ("Joe", "joe@joe.com", "joejoejoe", "joejoejoe");
        addUser ("Foobar","foo@bar.com", "foofoofoo", "foofoofoo");
        addUser ("NetBeans Rocks","netbeans@rocks.com", "netbeansrocks", "netbeansrocks");
        addUser ("Wicket Rocks", "wicket@rocks.com", "wicketrocks", "wicketrocks");
        addUser ("Positive Attitude", "isnt@this.fun", "isntThisFun", "isntThisFun");
        addUser ("Poodle Farmers Guild", "poodlefarmer@bubblebar.com", "poodles", "poodles");
    }
    /**
     * Add a user.
     * @param emailAddress their email address which will act as a unique id
     * @param password the password the user should get
     * @param repeatPassword the same password entered again - it must match
     * @return an error code, or null if the user has been added
     */ 
    public UserErrorCode addUser (String name, String emailAddress, String password, 
                                  String repeatPassword) {
        if (password.length() < 5) {
            return UserErrorCode.BAD_PASSWORD;
        }
        if (!emailAddress.contains("@")) {
            return UserErrorCode.BAD_EMAIL;
        }
        if (!password.equals(repeatPassword)) {
            return UserErrorCode.NON_MATCHING_PASSWORD;
        }
        User existing = getUser (emailAddress);
        if (existing != null) {
            return UserErrorCode.USER_EXISTS;
        }
        User nue = new User (name, emailAddress, password);
        users.add (nue);
        return null;
    }
    
    /**
     * Log the user in.
     * @param emailAddress their email address
     * @param password the password they entered in the login form
     */ 
    public UserErrorCode authenticate (String emailAddress, String password) {
        User user = getUser (emailAddress);
        if (user == null) {
            return UserErrorCode.UNKNOWN_USER;
        }
        if (!user.matchPassword(password)) {
            //Well, if you wanted to be secure you'd return unknown user here
            return UserErrorCode.INCORRECT_PASSWORD;
        }
        onAuthenticate (user);
        return null;
    }
    
    public User getUser (String emailAddress) {
        for (User user : users) {
            if (emailAddress.equalsIgnoreCase(user.getEmailAddress())) {
                return user;
            }
        }
        return null;
    }
    
    public List <User> getAllUsers() {
        List <User> result = new ArrayList <User> (users);
        Collections.sort(result);
        return result;
    }
    
    protected abstract void onAuthenticate (User user);
}
