/*
 * __NAME__.java
 *
 * Created on __DATE__, __TIME__
 */

package com.myapp.wicket.support;

import com.myapp.wicket.HomePage;
import org.apache.wicket.protocol.http.WebApplication;
/**
 *
 * @author __USER__
 * @version
 */

public class WicketApplication extends WebApplication {
    
    public WicketApplication() {
    }
    
    public Class getHomePage() {
        return HomePage.class;
    }
}
