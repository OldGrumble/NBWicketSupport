/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.netbeans.examples.wicket.login;

import org.apache.wicket.PageParameters;
import org.netbeans.examples.wicket.UserDatabase;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.PasswordTextField;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.util.value.ValueMap;
import org.netbeans.examples.wicket.UserErrorCode;
import org.netbeans.examples.wicket.ExampleApplication;

/**
 * Reusable user sign in panel with username and password as well as support for
 * cookie persistence of the both. When the SignInPanel's form is submitted, the
 * abstract method signIn(String, String) is called, passing the username and
 * password submitted. The signIn() method should sign the user in and return
 * null if no error ocurred, or a descriptive String in the event that the sign
 * in fails.
 *
 * @author Jonathan Locke
 * @author Juergen Donnerstag
 * @author Eelco Hillenius
 */
public abstract class RegisterPanel extends Panel {
    /** Field for password. */
    private PasswordTextField password;

    /** Field for repeat assword. */
    private PasswordTextField repeatPassword;
    
    /** Field for user name. */
    private TextField emailAddress;

    private TextField name;
    
    public String getName() {
        return name.getModelObject().toString();
    }

    /**
     * @param id
     *            See Component constructor
     * @param includeRememberMe
     *            True if form should include a remember-me checkbox
     * @see org.apache.wicket.Component#Component(String)
     */
    public RegisterPanel(final String id) {
        super(id);

        // Add register form to page, passing feedback panel as
        // validation error handler
        add(new RegisterForm("registerForm"));
    }

    /**
     * Convenience method to access the password.
     *
     * @return The password
     */
    public String getPassword() {
        return password.getModelObject().toString();
    }
    
    public String getRepeatPassword() {
        return repeatPassword.getModelObject().toString();
    }
    
    /**
     * Convenience method to access the username.
     *
     * @return The user name
     */
    public String getUsername() {
        return emailAddress.getModelObject().toString();
    }


    /**
     * Sign in user if possible.
     *
     * @param username
     *            The username
     * @param password
     *            The password
     * @return True if signin was successful
     */
    public abstract UserErrorCode signIn(String username, 
                                         String emailAddress, 
                                         String password, 
                                         String repeatPassword);
    
/**
     * Sign in form.
     */
    public final class RegisterForm extends Form {

        /** El-cheapo model for form. */
        private final ValueMap properties = new ValueMap();
        
        /**
         * Constructor.
         *
         * @param id
         *            id of the form component
         */
        public RegisterForm(final String id) {
            super(id);
            // Attach textfield components that edit properties map
            // in lieu of a formal beans model
            add(name = new TextField("register-name", new PropertyModel(properties, "name")));
            add(emailAddress = new TextField("register-username", new PropertyModel(properties, "username")));
            add(password = new PasswordTextField("register-password", new PropertyModel(properties, "password")));
            add(repeatPassword = new PasswordTextField("repeat-password", new PropertyModel(properties, "password")));
        }

        /**
         * @see org.apache.wicket.markup.html.form.Form#onSubmit()
         */
        @Override
        public final void onSubmit() {
            String email = getUsername();
            String pword = getPassword();
            String name = getName();
            UserErrorCode signInResult = signIn(name, email, pword, getRepeatPassword());
            if (signInResult == null) {
                UserDatabase db = 
                        ((ExampleApplication) getApplication()).getUserDatabase();
                
                signInResult = db.authenticate(email, pword);
                assert signInResult == null : "Newly created user id " + email + 
                        "could not be logged in: " + signInResult;
                // If login has been called because the user was not yet
                // logged in, than continue to the original destination,
                // otherwise to the Home page
                if (!continueToOriginalDestination()) {
                    //Could construct a HomePage instance here, but it is better
                    //to be in the habit of using PageParameters, as they can
                    //also be used to construct links
                    PageParameters urlParams = new PageParameters ();
                    urlParams.add ("message", "Thank you for registering, " + 
                            name + "!");
                    setResponsePage(getApplication().getHomePage(), urlParams);
                }
            } else {
                // Try the component based localizer first. If not found try the
                // application localizer. Else use the default
                final String errmsg = signInResult.toString();//getLocalizer().getString("loginError", this, "Unable to sign you in");
                //Display it in the feedbackpanel in SignInPage
                error(errmsg);
            }
        }
    }
}
