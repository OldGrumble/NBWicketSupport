/*
 * UsersPanel.java
 *
 * Created on Aug 15, 2007, 2:13:38 AM
 *
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.netbeans.examples.wicket.home;

import java.util.List;
import org.apache.wicket.Application;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.markup.repeater.Item;
import org.apache.wicket.markup.repeater.data.DataView;
import org.apache.wicket.markup.repeater.data.IDataProvider;
import org.apache.wicket.markup.repeater.data.ListDataProvider;
import org.apache.wicket.model.PropertyModel;
import org.netbeans.examples.wicket.ExampleApplication;
import org.netbeans.examples.wicket.pojos.User;

/**
 *
 * @author Tim Boudreau
 */
class UsersPanel extends Panel {

    public UsersPanel(String id) {
        super(id);
        ExampleApplication app = (ExampleApplication) Application.get();
        List<User> users = app.getUserDatabase().getAllUsers();

        IDataProvider provider = new ListDataProvider(users);
        DataView usersTable = new DataView("all-users", provider) {
            protected void populateItem(Item item) {
                User user = (User) item.getModelObject();
                item.add(new Label("name", new PropertyModel(user, "name")));
                item.add(new Label("emailAddress", new PropertyModel (user, "emailAddress")));
                item.add(new Label("passwordHash", new PropertyModel (user, "passwordHash")));
            }
        };
        add(usersTable);
    }
}
