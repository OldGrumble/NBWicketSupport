/*
 * __NAME__.java
 *
 * Created on __DATE__, __TIME__
 */

package com.myapp.wicket;

import com.myapp.wicket.support.WicketExamplePage;
import java.util.Arrays;
import java.util.List;
import org.apache.wicket.markup.html.form.CheckBox;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.model.CompoundPropertyModel;

public class HomePage extends WicketExamplePage {
    
    private static final List<CrustType> AVAILABLE_CRUSTS = 
            Arrays.<CrustType>asList(new CrustType[]{
                new CrustType("Thin & Crispy"), 
                new CrustType("Hand Tossed"), 
                new CrustType("Pan Pizza"),
            });
    PizzaForm pizzaForm = new PizzaForm("pizzaForm");

    public HomePage() {
        super();
        add(pizzaForm);
    }

    private class PizzaForm extends Form {
        private DropDownChoice crustDropDown;
        private CheckBox pepperoniCheckBox = new CheckBox("pepperoni");
        private CheckBox sausageCheckBox = new CheckBox("sausage");
        private CheckBox onionsCheckBox = new CheckBox("onions");
        private CheckBox greenPeppersCheckBox = new CheckBox("greenPeppers");
        private TextField commentsTextField = new TextField("comments");

        public PizzaForm(String id) {
            super(id);
            PizzaPojo pizzaPojo = new PizzaPojo();
            setModel(new CompoundPropertyModel(pizzaPojo));

            //This is Wicket magic:  Since our pizza has a property called
            //crust, the dropdown will automagically assign its value to
            //that property.  So we do not have to write any code to wire
            //up our web UI with our java model objects.
            crustDropDown = new DropDownChoice("crust", AVAILABLE_CRUSTS);
            
            //Alternately, you could do something like this, if you want to 
            //use the reflection magic on a different object
//            crustDropDown = new DropDownChoice("crust", 
//                    new PropertyModel(pizzaModel, "crust"), AVAILABLE_CRUSTS);
            
            add(crustDropDown);
            add(pepperoniCheckBox);
            add(sausageCheckBox);
            add(onionsCheckBox);
            add(greenPeppersCheckBox);
            add(commentsTextField);
        }

        @Override
        protected void onSubmit() {
            PizzaPojo pizzaModel = (PizzaPojo) getModelObject();
            setResponsePage(new ConfirmationPage(pizzaModel));
        }
    }
}
