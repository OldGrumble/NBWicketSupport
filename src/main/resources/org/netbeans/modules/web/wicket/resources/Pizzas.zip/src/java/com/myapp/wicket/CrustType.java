/*
 * CrustType.java
 *
 * Created on March 19, 2006, 7:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.myapp.wicket;

import java.io.Serializable;

/**
 *
 * @author Geertjan Wielenga
 */
public class CrustType implements Serializable {

    String id;
    String text;

    public CrustType() {
        super();
    }

    public CrustType(String crustName) {
        setId(crustName);
        setText(crustName);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String value) {
        this.text = value;
    }

    @Override
    public String toString() {
        return getText();
    }
}
