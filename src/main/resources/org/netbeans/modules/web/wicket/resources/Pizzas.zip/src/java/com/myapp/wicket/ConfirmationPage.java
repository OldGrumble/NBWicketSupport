/*
 * ConfirmationPage.java
 *
 * Created on March 19, 2006, 1:13 PM
 *
 */

package com.myapp.wicket;

import com.myapp.wicket.support.WicketExamplePage;
import org.apache.wicket.markup.html.basic.Label;

public class ConfirmationPage extends WicketExamplePage {

    public ConfirmationPage(PizzaPojo pizzaModel) {
        super();
        add(new Label("crust", pizzaModel.getCrust()));
        add(new Label("pepperoni", new Boolean(pizzaModel.getPepperoni()).toString()));
        add(new Label("sausage", new Boolean(pizzaModel.getSausage()).toString()));
        add(new Label("onions", new Boolean(pizzaModel.getOnions()).toString()));
        add(new Label("greenPeppers", new Boolean(pizzaModel.getGreenPeppers()).toString()));
        add(new Label("comments", pizzaModel.getComments()));
    }
}
