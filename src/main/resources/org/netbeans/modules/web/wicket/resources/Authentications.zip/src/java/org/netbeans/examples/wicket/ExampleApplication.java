/*
 * __NAME__.java
 *
 * Created on __DATE__, __TIME__
 */

package org.netbeans.examples.wicket;

import org.apache.wicket.Request;
import org.apache.wicket.Response;
import org.apache.wicket.Session;
import org.netbeans.examples.wicket.home.HomePage;
import org.apache.wicket.protocol.http.WebApplication;
import org.apache.wicket.protocol.https.HttpsConfig;
import org.apache.wicket.protocol.https.HttpsRequestCycleProcessor;
import org.apache.wicket.request.IRequestCycleProcessor;
import org.apache.wicket.settings.Settings;
import org.apache.wicket.util.lang.PackageName;
import org.netbeans.examples.wicket.login.SignInPage;
import org.netbeans.examples.wicket.pojos.User;

/**
 *
 * @author Tim Boudreau
 */
public class ExampleApplication extends WebApplication {
    private final UserDatabase userDatabase;
    public ExampleApplication() {
        //Create our fake pre-populated user database
        userDatabase = new UserDatabase() {
            protected void onAuthenticate(User user) {
                ExampleSession sess = (ExampleSession) Session.get();
                sess.setCurrentUser(user);
            }
        };
    }

    private int getSslPort() {
        //This will probably need to be changed depending on the server!
        //Glassfish uses 8181;  JBoss's default is different, probably
        //others too
        return 8181;
    }

    @Override
    protected void init() {
        //Need this for ssl to work
        getRequestCycleSettings().setRenderStrategy(Settings.ONE_PASS_RENDER);
        //Might as well send them back to the sign in page
        getApplicationSettings().setAccessDeniedPage(SignInPage.class);
        //This will block users from accessing pages whose classes have our
        //you-must-login annotation
        getSecuritySettings().setAuthorizationStrategy(new PageAccessHandler());
        //Get rid of those nasty wicket:::interface3 urls
        mount("examples/", PackageName.forClass(HomePage.class));
        mount("examples/login", PackageName.forClass(SignInPage.class));
    }

    public Class getHomePage() {
        return HomePage.class;
    }

    @Override
    public Session newSession(Request request, Response response) {
        //create an instance of our custom session that knows what
        //user is logged in
        return new ExampleSession(this, request);
    }

    /**
     * Getter so components can find the user database
     */ 
    public UserDatabase getUserDatabase() {
        return userDatabase;
    }

    @Override
    public IRequestCycleProcessor newRequestCycleProcessor() {
        //Provide our own request cycle processor which will look for
        //RequiresSSL annotations on pages it should show, and can 
        //switch over to SSL when needed
        //return new SwitchToSslHandler(getSslPort());
        return new HttpsRequestCycleProcessor(new HttpsConfig(8080, getSslPort()));
    }
}
