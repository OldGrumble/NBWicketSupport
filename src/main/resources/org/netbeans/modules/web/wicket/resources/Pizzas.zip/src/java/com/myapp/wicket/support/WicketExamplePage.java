/*
 * WicketExamplePage.java
 *
 * Created on October 14, 2006, 12:29 AM
 */
 
package com.myapp.wicket.support;           

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.model.IModel;
import org.apache.wicket.util.string.Strings;

/** 
 *
 * @author Geertjan Wielenga
 * @version 
 */

public class WicketExamplePage extends WebPage {

    /**
     * Constructor
     */
    public WicketExamplePage() {
        this(null);
    }
    
    /**
     * Construct.
     * @param model
     */
    public WicketExamplePage(IModel model) {
        super(model);
        final String packageName = getClass().getPackage().getName();
        add(new WicketExampleHeader("mainNavigation", Strings.afterLast(packageName, '.')));
        
    }
}
