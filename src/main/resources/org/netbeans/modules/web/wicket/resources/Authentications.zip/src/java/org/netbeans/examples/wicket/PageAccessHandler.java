/*
 * Authorization.java
 *
 * Created on Aug 15, 2007, 3:40:51 AM
 *
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.netbeans.examples.wicket;

import javax.management.relation.Role;
import org.apache.wicket.Component;
import org.apache.wicket.RestartResponseAtInterceptPageException;
import org.apache.wicket.Session;
import org.apache.wicket.authorization.Action;
import org.apache.wicket.authorization.IAuthorizationStrategy;
import org.apache.wicket.authorization.IAuthorizationStrategy;
import org.netbeans.examples.wicket.login.SignInPage;
import org.netbeans.examples.wicket.pojos.User;

/**
 *
 * @author tim
 */
public class PageAccessHandler implements IAuthorizationStrategy {

    public boolean isActionAuthorized(Component component, Action action) {
        return true;
    }

    public boolean isInstantiationAuthorized(Class componentClass) {
        ExampleSession session = (ExampleSession) Session.get();
        boolean isSignedIn = session.isSignedIn();
        
        boolean pageRequiresLogin = 
                componentClass.isAnnotationPresent(RequiresSignin.class);
        
        if (pageRequiresLogin && !isSignedIn) {
            //bounce them to the login page - the login page will send them
            //where they're going if they log in successfully
            throw new RestartResponseAtInterceptPageException(SignInPage.class);
        }
        return true;
    }
}
