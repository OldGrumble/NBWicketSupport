/*
 * User.java
 * 
 * Created on Aug 15, 2007, 1:16:22 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.netbeans.examples.wicket.pojos;

import java.io.Serializable;
import org.jasypt.util.password.StrongPasswordEncryptor;

/**
 *
 * @author Tim Boudreau
 */
public final class User implements Comparable <User>, Serializable {
    private final String emailAddress;
    private final String name;
    private String password;
    public User (String name, String emailAddress, String password) {
        assert emailAddress != null;
        assert password != null;
        assert name != null;
        this.emailAddress = emailAddress;
        this.name = name;
        setPassword (password);
    }
    
    public String getName() {
        return name;
    }
    
    public String getEmailAddress() {
        return emailAddress;
    }
    
    public boolean matchPassword(String password) {
        StrongPasswordEncryptor passwordEncryptor = 
                new StrongPasswordEncryptor();
        
        return passwordEncryptor.checkPassword(password, this.password);
    }
    
    public void setPassword (String s) {
        this.password = encryptPassword(s);
    }
    
    public String getPasswordHash() {
        //No need for a method like this, except to give us something to show
        //on the home page for this example app
        return this.password;
    }
    
    private static String encryptPassword (String password) {
        StrongPasswordEncryptor passwordEncryptor = 
                new StrongPasswordEncryptor();
        
        String encryptedPassword = passwordEncryptor.encryptPassword(password);
        return encryptedPassword;
    }

    public int compareTo(User other) {
        return getName().compareToIgnoreCase(other.getName());
    }
    
    @Override
    public String toString() {
        return name + " <" + getEmailAddress() + '>';
    }
    
    @Override
    public boolean equals(Object o) {
        boolean result = o.getClass() == User.class;
        if (result) {
            result = getEmailAddress().equals(((User) o).getEmailAddress());
        }
        return result;
    }
    
    @Override
    public int hashCode() {
        return getEmailAddress().hashCode() * 17;
    }
}
